/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto_integrador;

import conectarMongo.ConectarMongo;
import java.sql.Connection;
import javax.swing.JOptionPane;

/**
 *
 * @author Windows
 */
public class loginCod {
    Conecta_BD obj = new Conecta_BD ();
    public void login (String senha, String email){
        Connection conexao = obj.connectionMySql();     
        
        String EmailC = email;
        String SenhaC = senha;
        // String EmailC = lblEmail.getText();
        // String SenhaC = lblSenha.getText();
                
        obj.selectSenhaC(conexao, SenhaC);
        obj.selectEmailC(conexao, EmailC);
        
        System.getProperty("user.dir");
        
   
        int i = 0;
        while(i == 0){
            if(EmailC.equals(obj.getEmailC()) && SenhaC.equals(obj.getSenhaC())){
                JOptionPane.showMessageDialog(null,"Logado");
                i = 1;
                ConectarMongo cm = new ConectarMongo();
                cm.deleteValues();
                cm.insertValues(EmailC, 1);
                Home h = new Home();
                h.setVisible(true);
            }else {
                JOptionPane.showMessageDialog(null,"ACESSO NEGADO");
            }
        }
            // TODO add your handling code here:
        //}
         obj.closeConnectionMySql(conexao);
    }
        
}
