
package projeto_integrador;

import java.sql.Connection;

/**
 *
 * @author Windows
 */
public class cadastroCod {
    Conecta_BD obj = new Conecta_BD ();

    public void cadastro(String nome, String CPF, String senha, String nomeUser, String email){
        Connection conexao = obj.connectionMySql();
        /*
        String nome = lblNome.getText();
        String CPF = lblCpf.getText();
        String senha = lblSenha.getText();
        String nome_usuario = lblUsername.getText();
        String email = lblEmail.getText();
        String ende = lblEndereco.getText();
        String bairro = lblBairro1.getText();
        String cep = lblCep.getText();
        String city = lblCid.getText();
        String tel = lblCel.getText();
        String tted = (String) cbTitulo.getSelectedItem();
        */
        //String dtNasc = dataMaker(dtData);
        
        obj.insereClient(conexao, nome, CPF, null, null, email, null, senha);
        
        obj.selectcountidC(conexao);
        int IdC= obj.getIdC();
        
       // obj.insereEndereco(conexao, tituEnde, ende, bairro, city, cep, IdC);
        
                
        Painel_login log = new Painel_login();
        log.setVisible(true);
       
        obj.closeConnectionMySql(conexao);  
    }
   public String dataMaker(String data){
        String dat[] = data.split("/");
        int ano = Integer.parseInt(dat[2]);
        System.out.println(ano);
        int mes = Integer.parseInt(dat[1]);
        System.out.println(mes);
        int dia = Integer.parseInt(dat[0]);
        System.out.println(dia);
        return ano+"-"+mes+"-"+dia;
    }
}
