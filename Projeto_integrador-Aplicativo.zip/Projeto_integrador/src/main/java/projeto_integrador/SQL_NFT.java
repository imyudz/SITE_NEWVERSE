/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto_integrador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Windows
 */
public class SQL_NFT {


    private static Connection conexao_MySql = null;
    //local onde o banco de dados esta presente. Por padrão, colocarei localhost,
    // mas vc pode mudar o local de acordo com sua necessidade
    private static String localBD = "localhost";
    
    //Aqui são os LINKS responsaveis pelo local onde o BD estar. é modificavel
    //de acordo com suas necessidades
    private static String LINK = "jdbc:mysql://" + localBD + ":3306/newverse";
    
    //tem essas alternativas de formato do link caso vc queura usar.
    //private static String LINK = jbdc:mysql://localhost:3306/coloque o nome do bd;
    //nome do usuario e senha com permissao de acesso ao BD. Voce coloque de acordo com o
    //usuario e a senha pertencente ai Banco de Dados
   
    private static final String usuario = "root";
    private static final String senha = "";

    
    private String nome, dono;
    private int Id, att;
    
    
     public Connection connectionMySql(){
        try{
            //defina o caminho para a conexao
            conexao_MySql = DriverManager.getConnection(LINK, usuario, senha);
            //se der tudo certo
            System.out.println("Conexão OK!");
        } catch (SQLException e){
            throw new RuntimeException("Ocorreu um problema na conexao com o BD", e);
            
        }
        return conexao_MySql;
    }       
    
    //Dados Alunos ************************************
    
    public String selectNum(Connection con, int e) {
       Connection connection = connectionMySql();
        System.out.println("selectNun OK");
       String sql = "Select(nome) "+ "from NFTS_autorais "+"where num_operacao= ?";
       String nome = "";
       PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setInt(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                setNome(result.getString("nome"));
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       return nome;
    }  
    
    public String selectNFYID(Connection con, int e) {
       Connection connection = connectionMySql();
        System.out.println("selectNun OK");
       String nome = "";
       PreparedStatement preparedStmt;
       String sql = "Select(id_nft_autoral) "+ "from NFTS_autorais "+"where num_operacao= ?";
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setInt(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                setId(result.getInt("id_nft_autoral"));
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       return nome;
    }  
    
    public String selectNFYdono(Connection con, int e) {
       Connection connection = connectionMySql();
        System.out.println("selectNun OK");
       String nome = "";
       PreparedStatement preparedStmt;
        
        String sql = "Select(dono) "+ "from NFTS_autorais "+"where num_operacao= ?";
        
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setInt(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                setDono(result.getString("dono"));
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       return nome;
    }  
    
    
    /////////////////////////////////////////////////////////////qq
    
    
    public String selectAllNftsNome(Connection con, int p, String e) {
       Connection connection = connectionMySql();
        System.out.println("selectNun OK");
       String nome = "";
       PreparedStatement preparedStmt;
       String sql = "Select(nome) "+ "from NFTS_autorais "+"where id_nft_autoral= ? and dono= ?";
        
       try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setInt(1, p);
           preparedStmt.setString(2, e);
           
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                setNome(result.getString("nome"));
                nome = (result.getString("nome"));
            }
           connection.close();
        } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       selectAllNftsId(con, nome);
       return nome;
    }  
    
    
    public String selectAllNftsId(Connection con, String n) {
       Connection connection = connectionMySql();
        System.out.println("selectNun OK");
       String nome = "";
       PreparedStatement preparedStmt;
       String sql = "Select(id_nft_autoral) "+ "from NFTS_autorais "+"where nome= ?";
        
       try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, n);
                      
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                setId(result.getInt("id_nft_autoral"));
            }
           connection.close();
        } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
        
       return nome;
    } 
    
     public int selectCount(Connection con,String dono){
        Connection connection = connectionMySql();
        PreparedStatement preparedStmt;
        int vl = 0;
        String sql = "select count(*) from NFTS_autorais where dono=?"; 
        try {
            preparedStmt = connection.prepareStatement(sql);

            //Efetua a troca do '?' pelos valores na query
            preparedStmt.setString(1, dono);
            
            ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                vl =(result.getInt(1));
                setAtt(result.getInt(1));
            }
           
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
      
        return vl;
    }
    
    /*public String addAtt(Connection con, String e) {
        Connection connection = connectionMySql();
        int i = getAtt();
        try {
            Statement stmt = con.createStatement();           
            boolean rs = stmt.execute("UPDATE cliente SET att = \""+i+"\" WHERE email = "+e+" LIMIT 1;");
            connection.close(); 
       } catch (Exception p){
            System.out.println("Erro!!"+e);
        }   
              
       return nome;
    }  
    
    public String selectAtt(Connection con,String e){
                
        Connection connection = connectionMySql();
        
        PreparedStatement preparedStmt;
        
        String sql = "Select(att) "+ "from cliente "+"where email= ?";
        try {
            preparedStmt = connection.prepareStatement(sql);

            //Efetua a troca do '?' pelos valores na query
            preparedStmt.setString(1, e);
            
            ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                setAtt(result.getInt("att"));
            }
           
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
        addAtt(con, e);
        return e;
    }*/
    
    
    
    
    /////////////////////////////////////////////////////////////q
    
    
     public String selectImag(Connection con, String e) {
       Connection connection = connectionMySql();
       String sql = "Select(tipo_arquivo) "+ "from NFTS_autorais "+"where id_nft_autoral= ?";
       String link = "";
       PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                link = (result.getString("tipo_arquivo"));
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
        return link;
    }
    
    public String selectDono(Connection con, String e) {
        Connection connection = connectionMySql();
        String sql = "Select(dono) "+ "from NFTS_autorais "+"where id_nft_autoral= ?";
        String link = "";
        PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                setDono(result.getString("dono"));
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
        return link;
    }
    
    public void updade(Connection con, String nome){
        
        try {
            Statement stmt = con.createStatement();           
            boolean rs = stmt.execute("UPDATE NFTS_autorais SET dono = \""+nome+"\" WHERE id_nft_autoral = "+getId()+" LIMIT 1;");
        } catch (Exception e){
            System.out.println("Erro!!"+e);
        }

    }
    /*
    *
    * CONEÇÃO ADM E MY SQL
    *
    */
    
    public int countV(){
        int i=0;
        Connection connection = connectionMySql();
        PreparedStatement preparedStmt;
    
        String sql = "select count(*) from NFTS_autorais where dono=\"sem dono\""; 
        try {
            preparedStmt = connection.prepareStatement(sql);

            //Efetua a troca do '?' pelos valores na query
                      
            ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                i =(result.getInt(1));
                
            }
           
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
        return i;
    }
    
    
    public ArrayList<String> selectNFTs(Connection con, int e){
        ArrayList<String> info = new ArrayList();
        String nome, dono;
        int id;
        Connection connection = connectionMySql();
        String sql = "Select (id_nft_autoral) "+ "from NFTS_autorais "+"where dono= \"sem dono\" and id_nft_autoral = ?;";

        PreparedStatement preparedStmt;
        //ID
        try {
            preparedStmt = connection.prepareStatement(sql);
            preparedStmt.setInt(1, e);
           //Efetua a troca do '?' pelos valores na query
          
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                info.add(result.getString("id_nft_autoral"));
            }
          
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
        //NOME
        sql = "Select (nome) "+ "from NFTS_autorais "+"where dono= \"sem dono\" and id_nft_autoral = ?;";
        try {
            preparedStmt = connection.prepareStatement(sql);
            preparedStmt.setInt(1, e);
           //Efetua a troca do '?' pelos valores na query
           
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                info.add(result.getString("nome"));
                
            }
          
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
        //dono
        sql = "Select (dono) "+ "from NFTS_autorais "+"where dono= \"sem dono\" and id_nft_autoral = ?;";
        try {
            preparedStmt = connection.prepareStatement(sql);
            preparedStmt.setInt(1, e);
           //Efetua a troca do '?' pelos valores na query
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                //setEmailA(result.getString("email"));
                info.add(result.getString("dono"));
                
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
         
         /*
        for(Document doc : docs.find()){
            info.add(doc.getString("nome"));
            info.add(doc.getString("email"));
            info.add(doc.getString("telefone"));
            info.add(doc.getString("mensagem"));
            info.add(doc.getString("contato"));
            info.add(doc.getString("motivo"));
            System.out.println("item: "+doc);
        }*/

        System.out.println("Array dados salvo ok");
        return info;
    }
    
    /*
    *
    * /CONEÇÃO ADM E MY SQL
    *
    */
    
    
    public void closeConnectionMySql(Connection con){
        try{
            if(con != null){
                con.close();
                System.out.println("Fechamento OK");
                
            }
            
        }catch(SQLException e){
            throw new RuntimeException("Ocorreu um problema para " + "encerrar a conexão com o BD.", e);
        }
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getDono() {
        return dono;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }

    public int getAtt() {
        return att;
    }

    public void setAtt(int att) {
        this.att = att;
    }
    
    
}

