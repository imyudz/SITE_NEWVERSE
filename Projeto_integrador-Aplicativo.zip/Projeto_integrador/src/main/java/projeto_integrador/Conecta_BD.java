/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto_integrador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JOptionPane;

/**
 *
 * @author Windows
 */
public class Conecta_BD {
    
    private static Connection conexao_MySql = null;
    //local onde o banco de dados esta presente. Por padrão, colocarei localhost,
    // mas vc pode mudar o local de acordo com sua necessidade
    private static String localBD = "localhost";
    
    //Aqui são os LINKS responsaveis pelo local onde o BD estar. é modificavel
    //de acordo com suas necessidades
    private static String LINK = "jdbc:mysql://" + localBD + ":3306/newverse";
    
    //tem essas alternativas de formato do link caso vc queura usar.
    //private static String LINK = jbdc:mysql://localhost:3306/coloque o nome do bd;
    //nome do usuario e senha com permissao de acesso ao BD. Voce coloque de acordo com o
    //usuario e a senha pertencente ai Banco de Dados
   
    private static final String usuario = "root";
    private static final String senha = "";
    
    // Antiga prog
    private String nomeA;
    private String nomeC;
    private String emailA;
    private String emailC;
    private String CPF;
    private String dt_nasc;
    private String telefone;
    private String ende;
    private String bairro;
    private String cidade;
    private String cep;
    private String nomeU;
    private String tituEnde; 
    
    //nome, cpf, dt_nasc, telefone, email
    // itens senha
    private String senhaA;
    private String senhaC;
    private String saidaAN;
    private String saidaAS;
    private String saidaCN;
    private String saidaCS;
    private String selectCity = "";
    private String selectAluno = "";
    public String SaidaA;
    public String SaidaC;
   
    //Antiga prog
    
    private int IdC;
    private int IdA;
    
    
    
    
    //Metodo para fazer a conecao com um banco de dados MySql
    public Connection connectionMySql(){
        try{
            //defina o caminho para a conexao
            conexao_MySql = DriverManager.getConnection(LINK, usuario, senha);
            //se der tudo certo
            System.out.println("Conexão OK!");
        } catch (SQLException e){
            throw new RuntimeException("Ocorreu um problema na conexao com o BD", e);
            
        }
        return conexao_MySql;
    }       
    
    //Dados Alunos ************************************
    
    public String selectEmailA(Connection con, String e) {
       Connection connection = connectionMySql();
       String sql = "Select(email) "+ "from aluno "+"where email= ?";
       String email = "";
       PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                setEmailA(result.getString("email"));
               
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
      
       return e;
    }   
    
  
   
   //nome,cpf, dt_nasc, telefone
    
    
    
    


    public String selectNomeC(Connection con, String e) {
       Connection connection = connectionMySql();
      
       String sql = "Select (nome)"+ "from cliente "+"where email= ?";
              
       PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               //setEmailA(result.getString("email"));
               setNomeC(result.getString("nome"));
               //setCPF(result.getString("cpf"));
               //setTelefone(result.getString("telefone"));
               //setDt_nasc(result.getString("dt_nasc"));
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
         System.out.println("selectNomeC OK");
       return e;
    }   

    public String selectCpf(Connection con, String e) {
       Connection connection = connectionMySql();
       String sql = "";
       
       sql = "Select (cpf)"+ "from cliente "+"where email= ?";
       
        PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               //setEmailA(result.getString("email"));
               //setNomeC(result.getString("nome"));
               setCPF(result.getString("cpf"));
               //setTelefone(result.getString("telefone"));
               //setDt_nasc(result.getString("dt_nasc"));
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       return e;
    }   

    public String selectDt(Connection con, String e) {
       Connection connection = connectionMySql();
       String sql = "";
       sql = "Select (dt_nasc)"+ "from cliente "+"where email= ?";
       
       
       PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               
               //setNomeC(result.getString("nome"));
               //setCPF(result.getString("cpf"));
               //setTelefone(result.getString("telefone"));
               setDt_nasc(result.getString("dt_nasc"));
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       return e;
    }   

    public String selectTele(Connection con, String e) {
       Connection connection = connectionMySql();
      
       String sql = "Select (telefone)"+ "from cliente "+"where email= ?";
       
       PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               
               //setNomeC(result.getString("nome"));
               //setCPF(result.getString("cpf"));
               setTelefone(result.getString("telefone"));
               //setDt_nasc(result.getString("dt_nasc"));
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       return e;
    }   

     public String selectUserName(Connection con, String e) {
       Connection connection = connectionMySql();
      
       String sql = "Select (nome_usuario)"+ "from cliente "+"where email= ?";
       
       PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               
                setNomeU(result.getString("nome_usuario"));
               //setNomeC(result.getString("nome"));
               //setCPF(result.getString("cpf"));
               //setTelefone(result.getString("telefone"));
               //setDt_nasc(result.getString("dt_nasc"));
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       return e;
    }   




 //nome,cpf, dt_nasc, telefone


    //SELECT ENDERECO E ID
    

    public int selectIdc(Connection con, String e) {
       Connection connection = connectionMySql();
       int id = 0;
       String sql = "Select (id_cliente)"+ "from cliente "+"where email= ?";
       
       PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               
               //setNomeC(result.getString("nome"));
               //setCPF(result.getString("cpf"));
               //setTelefone(result.getString("telefone"));
               //setDt_nasc(result.getString("dt_nasc"));
               setIdC(result.getInt("id_cliente"));
               
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       return id;
    }   
    
    
    public void SelectEndereco(Connection con){
        
        Connection connection = connectionMySql();
      
        String sql = "Select (rua_numero)"+ "from endereco_cliente "+"where fk_pk_id_cliente= ?";
       
        PreparedStatement preparedStmt;
            try {
                preparedStmt = connection.prepareStatement(sql);

                //Efetua a troca do '?' pelos valores na query
                preparedStmt.setInt(1, getIdC());
                ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               
               //setNomeC(result.getString("nome"));
               //setCPF(result.getString("cpf"));
                setEnde(result.getString("rua_numero"));
               //setDt_nasc(result.getString("dt_nasc"));
            
            }
            connection.close();
        } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
    }   
    
    public void SelectBairro(Connection con){
        
        Connection connection = connectionMySql();
      
        String sql = "Select (bairro)"+ "from endereco_cliente "+"where fk_pk_id_cliente= ?";
       
        PreparedStatement preparedStmt;
            try {
                preparedStmt = connection.prepareStatement(sql);

                //Efetua a troca do '?' pelos valores na query
                preparedStmt.setInt(1, getIdC());
                ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               
               //setNomeC(result.getString("nome"));
               //setCPF(result.getString("cpf"));
                setBairro(result.getString("bairro"));
               //setDt_nasc(result.getString("dt_nasc"));
            
            }
            connection.close();
        } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
    }   
    
    public void SelectCep(Connection con){
        
        Connection connection = connectionMySql();
      
        String sql = "Select (CEP)"+ "from endereco_cliente "+"where fk_pk_id_cliente= ?";
       
        PreparedStatement preparedStmt;
            try {
                preparedStmt = connection.prepareStatement(sql);

                //Efetua a troca do '?' pelos valores na query
                preparedStmt.setInt(1, getIdC());
                ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               
               //setNomeC(result.getString("nome"));
               //setCPF(result.getString("cpf"));
                setCep(result.getString("CEP"));
               //setDt_nasc(result.getString("dt_nasc"));
            
            }
            connection.close();
        } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
    }   
    
    public void SelectCida(Connection con){
        
        Connection connection = connectionMySql();
      
        String sql = "Select (cidade)"+ "from endereco_cliente "+"where fk_pk_id_cliente= ?";
       
        PreparedStatement preparedStmt;
            try {
                preparedStmt = connection.prepareStatement(sql);

                //Efetua a troca do '?' pelos valores na query
                preparedStmt.setInt(1, getIdC());
                ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               
               //setNomeC(result.getString("nome"));
               //setCPF(result.getString("cpf"));
                setCidade(result.getString("cidade"));
               //setDt_nasc(result.getString("dt_nasc"));
            
            }
            connection.close();
        } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
    }
    
    public void SelectTituEnde(Connection con){
        
        Connection connection = connectionMySql();
      
        String sql = "Select (titulo_endereco)"+ "from endereco_cliente "+"where fk_pk_id_cliente= ?";
       
        PreparedStatement preparedStmt;
            try {
                preparedStmt = connection.prepareStatement(sql);

                //Efetua a troca do '?' pelos valores na query
                preparedStmt.setInt(1, getIdC());
                ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               
               //setNomeC(result.getString("nome"));
               //setCPF(result.getString("cpf"));
                setTituEnde(result.getString("titulo_endereco"));
               //setDt_nasc(result.getString("dt_nasc"));
            
            }
            connection.close();
        } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
    }   
    
    // ENDERECO E ID
    
  
    
        

    
    // Dados dos clientes ***********************************
    public String selectEmailC(Connection con, String e) {
       Connection connection = connectionMySql();
       String sql = "Select(email) "+ "from Cliente "+"where email= ?";
       String email = "";
       PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                setEmailC(result.getString("email"));
               
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       
       return e;
    }   
    
    public String selectSenhaC(Connection con, String s) {
       Connection connection = connectionMySql();
       String sql = "Select(senha) "+ "from Cliente "+"where senha= ?";
       String senha = "";
       PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, s);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               
               setSenhaC(result.getString("senha"));
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       
       return s;
    }   
    

    
        
    //fecha conexao
    public void closeConnectionMySql(Connection con){
        try{
            if(con != null){
                con.close();
                System.out.println("Fechamento OK");
                
            }
            
        }catch(SQLException e){
            throw new RuntimeException("Ocorreu um problema para " + "encerrar a conexão com o BD.", e);
        }
    }
    
    //**************************INSERT INTO*****************************
    // INSERT CLIENTE
    public void insereClient(Connection con,String nome, String CPF, String telefone,String dt_nasc, String email, String nome_usuario, String senha){

       try{
        String sql = "INSERT INTO Cliente (id_cliente, nome, CPF, telefone, dt_nasc, email, nome_usuario, senha, att) VALUES(null,?,?,?,?,?,?,?,?)";
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, nome);
        pstm.setString(2, CPF);
        pstm.setString(3, telefone);
        pstm.setString(4, dt_nasc);
        pstm.setString(5, email);
        pstm.setString(6, nome_usuario);
        pstm.setString(7, senha); 
        pstm.execute();  

       }catch(Exception e){
           System.out.println("Erro ao inserir no Aluno!"+e);
       }
    }

    // INSERT ENDERECO
    public void insereEndereco(Connection con, String titulo_endereco, String rua_numero, String bairro, String cidade, String CEP, int fk_pk_id_cliente){

        try{
            String sql = "INSERT INTO endereco_cliente (titulo_endereco, rua_numero, bairro, cidade, CEP, fk_pk_id_cliente) VALUES(?, ?, ?, ?, ?, ?)";
            PreparedStatement pstm = con.prepareStatement(sql);
           
            pstm.setString(1, titulo_endereco);
            pstm.setString(2, rua_numero);
            pstm.setString(3, bairro);
            pstm.setString(4, cidade);
            pstm.setString(5, CEP);
            pstm.setInt(6, fk_pk_id_cliente);
            pstm.execute();

        }catch(Exception e){
            System.out.println("Erro ao inserir na Cidade!"+e);
        }
    }

    // INSERT ALUNO

    //********CONTAGEM DE ALUNO
    //select count(id_aluno) from Aluno; 

    
  
    
    public void selectcountidC(Connection con){
        String Saida = "";
        try{
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select count(id_cliente) from Cliente");
            
            while (rs.next()){   
                
                setIdC(rs.getInt(1));
                               
            }
                    
        } catch (Exception e){
            System.out.println(e);
        }
    }

    // UPDATE (String nome, String CPF, String senha, String nomeUser, String email, String ende, String bairro, 
    //String cep, String city, String tel, String tituEnde, String dtData, String att
    public void updade(Connection con, String nome, String nomeUser, String ende, String bairro, 
    String cep, String city, String tel, String dtData, String tituEnde){
        
        try {
            Statement stmt = con.createStatement();           
            boolean rs = stmt.execute("UPDATE cliente SET nome = \""+nome+"\" WHERE id_cliente = "+getIdC()+" LIMIT 1;");
        } catch (Exception e){
            System.out.println("Erro!!"+e);
        }
        
        try {
            Statement stmt = con.createStatement();           
            boolean rs = stmt.execute("UPDATE cliente SET nome_usuario = \""+nomeUser+"\" WHERE id_cliente = "+getIdC()+" LIMIT 1;");
        } catch (Exception e){
            System.out.println("Erro!!"+e);
        }

        try {
            Statement stmt = con.createStatement();           
            boolean rs = stmt.execute("UPDATE cliente SET telefone = \""+tel+"\" WHERE id_cliente = "+getIdC()+" LIMIT 1;");
        } catch (Exception e){
            System.out.println("Erro!!"+e);
        }
        
        try {
            Statement stmt = con.createStatement();           
            boolean rs = stmt.execute("UPDATE cliente SET dt_nasc = \""+dtData+"\" WHERE id_cliente = "+getIdC()+" LIMIT 1;");
        } catch (Exception e){
            System.out.println("Erro!!"+e);
        }
        
        // ENDERECO
        
        try {
            Statement stmt = con.createStatement();           
        boolean rs = stmt.execute("UPDATE endereco_cliente SET cidade = \""+city+"\" WHERE fk_pk_id_cliente = "+getIdC()+" LIMIT 1;");
        } catch (Exception e){
            System.out.println("Erro!!"+e);
        }
        
        try {
            Statement stmt = con.createStatement();           
            boolean rs = stmt.execute("UPDATE endereco_cliente SET CEP = \""+cep+"\" WHERE fk_pk_id_cliente = "+getIdC()+" LIMIT 1;");
        } catch (Exception e){
            System.out.println("Erro!!"+e);
        }
        
        try {
            Statement stmt = con.createStatement();           
            boolean rs = stmt.execute("UPDATE endereco_cliente SET bairro = \""+bairro+"\" WHERE fk_pk_id_cliente = "+getIdC()+" LIMIT 1;");
        } catch (Exception e){
            System.out.println("Erro!!"+e);
        }
        
        try {
            Statement stmt = con.createStatement();           
            boolean rs = stmt.execute("UPDATE endereco_cliente SET rua_numero = \""+ende+"\" WHERE fk_pk_id_cliente = "+getIdC()+" LIMIT 1;");
        } catch (Exception e){
            System.out.println("Erro!!"+e);
        }
        try {
            Statement stmt = con.createStatement();           
            boolean rs = stmt.execute("UPDATE endereco_cliente SET titulo_endereco = \""+tituEnde+"\" WHERE fk_pk_id_cliente = "+getIdC()+" LIMIT 1;");
        } catch (Exception e){
            System.out.println("Erro!!"+e);
        }
    }

    public String getNomeU() {
        return nomeU;
    }

    public void setNomeU(String nomeU) {
        this.nomeU = nomeU;
    }
    
    
    
    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getDt_nasc() {
        return dt_nasc;
    }

    public void setDt_nasc(String dt_nasc) {
        this.dt_nasc = dt_nasc;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    
    public int getIdA() {
        return IdA;
    }

    public void setIdA(int IdA) {
        this.IdA = IdA;
    }

    public int getIdC() {
        return IdC;
    }

    public void setIdC(int IdC) {
        this.IdC = IdC;
    }

    public String getNomeA() {
        return nomeA;
    }

    public void setNomeA(String nomeA) {
        this.nomeA = nomeA;
    }

    public String getNomeC() {
        return nomeC;
    }

    public void setNomeC(String nomeC) {
        this.nomeC = nomeC;
    }

    public String getEmailA() {
        return emailA;
    }

    public void setEmailA(String emailA) {
        this.emailA = emailA;
    }

    public String getEmailC() {
        return emailC;
    }

    public void setEmailC(String emailC) {
        this.emailC = emailC;
    }

    public String getSenhaA() {
        return senhaA;
    }

    public void setSenhaA(String senhaA) {
        this.senhaA = senhaA;
    }

    public String getSenhaC() {
        return senhaC;
    }

    public void setSenhaC(String senhaC) {
        this.senhaC = senhaC;
    }

    public String getSaidaAN() {
        return saidaAN;
    }

    public void setSaidaAN(String saidaAN) {
        this.saidaAN = saidaAN;
    }

    public String getSaidaAS() {
        return saidaAS;
    }

    public void setSaidaAS(String saidaAS) {
        this.saidaAS = saidaAS;
    }

    public String getSaidaCN() {
        return saidaCN;
    }

    public void setSaidaCN(String saidaCN) {
        this.saidaCN = saidaCN;
    }

    public String getSaidaCS() {
        return saidaCS;
    }

    public void setSaidaCS(String saidaCS) {
        this.saidaCS = saidaCS;
    }

    public String getSelectCity() {
        return selectCity;
    }

    public void setSelectCity(String selectCity) {
        this.selectCity = selectCity;
    }
    
    public String getSelectAluno() {
        return selectAluno;
    }

    public void setSelectAluno(String selectAluno) {
        this.selectAluno = selectAluno;
    }

    public String getEnde() {
        return ende;
    }

    public void setEnde(String ende) {
        this.ende = ende;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getTituEnde() {
        return tituEnde;
    }

    public void setTituEnde(String tituEnde) {
        this.tituEnde = tituEnde;
    }

    

}
