
package conectar;

import conectarMongo.*;

public class Entrada {
    private int id, flag;
    private String nome;
    private String email, log;
    private boolean esta_trabalhando, recebEmail;
    private String nomeCont, emailCont, telef, mensag, MeioDContato, motivo;
//String nome, String email, String telefone, String mensagem, String meioDcontado, String motivo, boolean recebEmail

    public boolean isRecebEmail() {
        return recebEmail;
    }

    public void setRecebEmail(boolean recebEmail) {
        this.recebEmail = recebEmail;
    }

    public String getNomeCont() {
        return nomeCont;
    }

    public void setNomeCont(String nomeCont) {
        this.nomeCont = nomeCont;
    }

    public String getEmailCont() {
        return emailCont;
    }

    public void setEmailCont(String emailCont) {
        this.emailCont = emailCont;
    }

    public String getTelef() {
        return telef;
    }

    public void setTelef(String telef) {
        this.telef = telef;
    }

    public String getMensag() {
        return mensag;
    }

    public void setMensag(String mensag) {
        this.mensag = mensag;
    }

    public String getMeioDContato() {
        return MeioDContato;
    }

    public void setMeioDContato(String MeioDContato) {
        this.MeioDContato = MeioDContato;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }
    
    
    public int getId() {
        return id;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    
    
    public void setId(int id) {
        this.id = id + 1;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    

    public boolean isEsta_trabalhando() {
        return esta_trabalhando;
    }

    public void setEsta_trabalhando(boolean esta_trabalhando) {
        this.esta_trabalhando = esta_trabalhando;
    }
    
    
}
