package conectar;

 

import java.sql.*;

 

public class conectar {

    private static Connection conexao_MySql = null;
    private static String localBD = "localhost";
    private static String LINK = "jdbc:mysql://" + localBD + ":3306/teste1";
    private static final String usuario = "root";
    private static final String senha = "";

    
    private String email;
    private String senhaC;

    // Método para fazer a conexão com um banco de dados MySql
    public Connection connectionMySql() {

 

        try {
            conexao_MySql = DriverManager.getConnection(LINK, usuario, senha);
            System.out.println("conexão OK!");
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um problema na conexão com o BD", e);
        }
        return conexao_MySql;
    }
    
    // INSERE OS CLIENTES NA PAGINA CADASTRO 
    
    public void insereClient(Connection con,String nome, String CPF,  String email, String nome_usuario, String senha){

       try{
        String sql = "INSERT INTO Cliente (id_cliente, nome, CPF, telefone, dt_nasc, email, nome_usuario, senha) VALUES(null,?,?,?,?,?,?,?,?)";
        PreparedStatement pstm = con.prepareStatement(sql);
        pstm.setString(1, nome);
        pstm.setString(2, CPF);
        pstm.setString(3, null);
        pstm.setString(4, null);
        pstm.setString(5, email);
        pstm.setString(6, null);
        pstm.setString(7, senha); 
        pstm.execute();  

       }catch(Exception e){
           System.out.println("Erro ao inserir no Aluno!"+e);
       }
    }
    
    
    public String selectEmailC(Connection con, String e) {
       Connection connection = connectionMySql();
       String sql = "Select(email) "+ "from Cliente "+"where email= ?";
       String email = "";
       PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, e);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
                setEmail(result.getString("email"));
               
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       
       return e;
    }   
    
    public String selectSenhaC(Connection con, String s) {
       Connection connection = connectionMySql();
       String sql = "Select(senha) "+ "from Cliente "+"where senha= ?";
       String senha = "";
       PreparedStatement preparedStmt;
        try {
            preparedStmt = connection.prepareStatement(sql);

           //Efetua a troca do '?' pelos valores na query
           preparedStmt.setString(1, s);
           ResultSet result = preparedStmt.executeQuery();
           //valida resultado
            while (result.next()) {             
               
               setSenhaC(result.getString("senha"));
            }
           connection.close();
       } catch (SQLException a) {
            // TODO Auto-generated catch block
            a.printStackTrace();
        }
       
       return s;
    }
    

 

    public void closeConnectionMySql(Connection con) {
        try {
            if (con != null) {
                con.close();
                System.out.println("Fechamento OK");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Ocorreu um problema para encerrar a conexão com o BD.", e);
        }
    }
    
    //public void dataBaseSelect(){
    //}

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenhaC() {
        return senhaC;
    }

    public void setSenhaC(String senhaC) {
        this.senhaC = senhaC;
    }

   
    
    
    
    
}