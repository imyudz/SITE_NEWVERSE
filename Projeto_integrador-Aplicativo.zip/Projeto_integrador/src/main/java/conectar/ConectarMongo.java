
package conectar;

import conectarMongo.*;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import java.util.ArrayList;
import org.bson.Document;

public class ConectarMongo {
    String database = "newverse";
    String collection = "login";
    String collection2 = "contato";
    Entrada u = new Entrada();
    
    private int contContat;
    
    public void getValues(){
        System.out.println("get Values");
        String uri = "mongodb://localhost";
        MongoClient mongo = MongoClients.create(uri);
        MongoDatabase db = mongo.getDatabase(database);
        MongoCollection<Document> docs = db.getCollection(collection);
        
    }
    public String selectValues(){
        String y = "";
        System.out.println("Select Values");
        System.out.println("get Values");
        String uri = "mongodb://localhost";
        MongoClient mongo = MongoClients.create(uri);
        MongoDatabase db = mongo.getDatabase(database);
        MongoCollection<Document> docs = db.getCollection(collection);
        for(Document doc:docs.find()){
            System.out.println("item: "+doc);
            y = doc.getString("email");
        }
        return y; 
    }
       
    
    
    // INSERE OS VALORES NO LOGIN
    
    public void insertValues(String email, int flag){
        System.out.println("insertValues");
        // conexao mongo
        String uri = "mongodb://localhost";
        MongoClient mongo = MongoClients.create(uri);
        MongoDatabase db = mongo.getDatabase(database);
        MongoCollection<Document> docs = db.getCollection(collection);
        Entrada user = createUser(email, flag);//cria um user obj // da classe
        //conectar, chamando o método createUser()- logo abaixo
        Document doc = createDocument(user);//cria um doc
        //que referencia o conteudo de usar do createDocument()
        //obs, o banco so entede objetos do tipo document,
        docs.insertOne(doc);
        System.out.println("insertValues ok");
    }
    
    public Entrada createUser(String email, int flag){
        //esse método deve ser uma entrada externa
        //(interface, scanner ou JOptionPanel
        u.setLog("");
        u.setEmail(email); 
        u.setFlag(flag);
        return u;
        }
    
    public Document createDocument(Entrada user){
        Document docBuilder = new Document();
        docBuilder.append("log",user.getLog());
        docBuilder.append("email", user.getEmail());
        docBuilder.append("flag", user.getFlag());
        return docBuilder;
    }
    
    
    // INSERIR OS DADOS DA ABA CADASTRO
    
    public void insertContato(String nome, String email, String telefone, String mensagem, String meioDcontado, String motivo, boolean recebEmail){
        System.out.println("insertValues");
        // conexao mongo
        String uri = "mongodb://localhost";
        MongoClient mongo = MongoClients.create(uri);
        MongoDatabase db = mongo.getDatabase(database);
        MongoCollection<Document> docs = db.getCollection(collection2);
        Entrada user = createContato( nome, email, telefone, mensagem, meioDcontado, motivo,  recebEmail);//cria um user obj // da classe
        //Entrada user = createContato("Sugiston", "sugi@gmail.com", "99999999", "muito bom gostei de tudo", "telefone", "Elogio",  true);//cria um user obj // da classe

        //conectar, chamando o método createUser()- logo abaixo
        Document doc = createDocContat(user);//cria um doc
        //que referencia o conteudo de usar do createDocument()
        //obs, o banco so entede objetos do tipo document,
        docs.insertOne(doc);
        System.out.println("insertValues ok");
    }
    
    public Entrada createContato(String nome, String email, String telefone, String mensagem, String meioDcontado, String motivo, boolean recebEmail){
        //esse método deve ser uma entrada externa
        //(interface, scanner ou JOptionPanel
        u.setId(selectId());
        u.setNomeCont(nome);
        u.setEmailCont(email); 
        u.setTelef(telefone);
        u.setMensag(mensagem);
        u.setMeioDContato(meioDcontado);
        u.setMotivo(motivo);
        u.setRecebEmail(recebEmail);
        return u;
        }
    
    public Document createDocContat(Entrada user){
        Document docBuilder = new Document();
        docBuilder.append("_id",user.getId());
        docBuilder.append("nome", user.getNomeCont());
        docBuilder.append("email", user.getEmailCont());
        docBuilder.append("telefone", user.getTelef());
        docBuilder.append("mensagem", user.getMensag());
        docBuilder.append("contato", user.getMeioDContato());
        docBuilder.append("motivo", user.getMotivo());
        docBuilder.append("receber_Email", user.isRecebEmail());
        return docBuilder;
    }
    
    
    
    public void deleteValues(){
        System.out.println("deleteValues");
        
        String uri = "mongodb://localhost";
        MongoClient mongo = MongoClients.create(uri);
        MongoDatabase db = mongo.getDatabase(database);
        MongoCollection<Document> docs = db.getCollection(collection);
   
        docs.deleteMany(Filters.eq("log",""));
        System.out.println("Documento teve sucesso no delete...");
        for(Document doc : docs.find()){
            System.out.println("item deleted: " + doc);
        }
    }
    
    public int selectId() {
        int Id = 0;
        System.out.println("Select Values");
        String uri = "mongodb://localhost";
        MongoClient mongo = MongoClients.create(uri);
        MongoDatabase db = mongo.getDatabase(database);
        MongoCollection<Document> docs = db.getCollection(collection2);
       
        for (Document doc : docs.find()) {
            System.out.println("item: " + doc);
            Id = (doc.getInteger("_id")); 
        }
        
        System.out.println("Select");
                  
        System.out.println("Select id ok");
        return Id;
    }
    
    
    /*
    *  CHECAR CONTATOS PARA PAÍNEL ADM *********************************
    */
    
    public ArrayList<String> selectContatos(int x){
        ArrayList<String> info = new ArrayList();
        String nome,  email, telefone, mensagem, meioDcontado, motivo;
        boolean recebEmail;
        System.out.println("getValues");
        String uri = "mongodb://localhost";
        MongoClient mongo = MongoClients.create(uri);
        MongoDatabase db = mongo.getDatabase(database);
        MongoCollection<Document> docs = db.getCollection(collection2);

        for(Document doc : docs.find(Filters.eq("_id", x))){
            info.add(doc.getString("nome"));
            info.add(doc.getString("email"));
            info.add(doc.getString("telefone"));
            info.add(doc.getString("mensagem"));
            info.add(doc.getString("contato"));
            info.add(doc.getString("motivo"));
            System.out.println("item: "+doc);
        }

        System.out.println("Array dados salvo ok");
        return info;
    
    }
        
    public int CountDados(){
        System.out.println("Select Values");
        String uri = "mongodb://localhost";
        MongoClient mongo = MongoClients.create(uri);
        MongoDatabase db = mongo.getDatabase(database);
        MongoCollection<Document> docs = db.getCollection(collection2);
        int i = (int) (docs.countDocuments());
        System.out.println(i);
        return i;
    }

    public void deleteConta(String e){
        System.out.println("deleteValues");
        
        String uri = "mongodb://localhost";
        MongoClient mongo = MongoClients.create(uri);
        MongoDatabase db = mongo.getDatabase(database);
        MongoCollection<Document> docs = db.getCollection(collection2);
   
        docs.deleteMany(Filters.eq("email", e));
        System.out.println("Documento teve sucesso no delete...");
        for(Document doc : docs.find()){
            System.out.println("item deleted: " + doc);
        }
    }
    
    
    public int getContContat() {
        return contContat;
    }

    public void setContContat(int contContat) {
        this.contContat = contContat;
    }
    

}
